package interfaces;

public interface Vendible {
    double calcularPrecioVenta(int cantidad);
}